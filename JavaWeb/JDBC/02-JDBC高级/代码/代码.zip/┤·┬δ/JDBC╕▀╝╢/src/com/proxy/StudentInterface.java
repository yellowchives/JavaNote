package com.proxy;

public interface StudentInterface {
    void eat(String name);
    void study();
}
