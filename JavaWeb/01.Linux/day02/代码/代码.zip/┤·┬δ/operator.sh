#!/bin/bash
#运算符
#整数相加
num1=`expr 2 + 2`
echo "整数2+2的结果为$num1"

#整数相减
num2=`expr 2 - 2`
echo "整数2-2的结果为$num2"

#整数相乘
num3=`expr 2 \* 2`
echo "整数2*2的结果为$num3"


#变量相加
a=10
b=20
num4=`expr $a + $b`
echo "变量a和变量b相加的结果为$num4"

#赋值
c=30
num5="${c}"
echo "变量c的值赋值给num5,打印num5的值$num5"

#自增
e=1
((e++))
echo "变量e为1，自增之后，结果为$e"








