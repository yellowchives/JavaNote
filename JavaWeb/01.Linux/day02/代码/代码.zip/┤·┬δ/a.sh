#!/bin/bash
#变量的定义
number=10
echo $number

a='$number'
echo $a


b="$number"
echo $b


c=`date`
echo $c

d=$(date)
echo $d


result="现在的时间为${d}"
echo "${result}"

#readonly result
unset result
echo "${result}"





