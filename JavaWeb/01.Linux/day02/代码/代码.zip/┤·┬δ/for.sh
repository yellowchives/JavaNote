#!/bin/bash
#for循环

for var in A B C D E F
do
	echo "${var}"
done
