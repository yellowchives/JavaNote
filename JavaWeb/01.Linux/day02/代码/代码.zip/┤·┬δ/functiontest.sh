#!/bin/bash
#方法的练习
#在方法中键盘录入两个整数,返回这两个整数的和
# read 变量名 --- 表示把键盘录入的数据复制给这个变量.

method(){
	echo "请录入第一个数"
	read number1
	echo "请录入第二个数"
	read number2
	echo "两个数字分别为${number1},${number2}"
	return $(($number1+$number2))
}


#方法的调用
method
echo $?
