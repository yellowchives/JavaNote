#!/bin/bash
#while循环
#打印1-10之间的每一个数

a=1
while [ "${a}" -le 10 ]
do
	echo "${a}"
	((a++))
done
