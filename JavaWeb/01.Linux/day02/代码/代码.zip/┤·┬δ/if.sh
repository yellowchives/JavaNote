#!/bin/bash
#if语句


#if的第一种格式:
#我要查找一个进程,如果这个进程存在,就打印true
if [ $(ps -ef | grep -c "ssh") -gt 1 ]
then
	echo "true"
fi


#if的第二种格式:
#我要查找一个进程,如果这个进存在,就打印true,否则就打印false
if [ $(ps -ef | grep -c "ssh") -gt 1 ]
then
	echo "true"
else
	echo "false"
fi

#if的第三种格式:
#定义a和b两个变量,针对于相等,大于,小于,进行三种提示
a=10
b=20

if [ "${a}" -eq "${b}" ]
then
	echo "相等"
elif [ "${a}" -lt "${b}" ]
then
	echo "a小于b"
else
	echo "a大于b"
fi

















