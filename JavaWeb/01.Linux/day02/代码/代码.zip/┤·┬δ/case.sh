#!/bin/bash
#选择结构语句

v="czbk"
case "${v}" in
"czbk")
	echo "传智播客"
	;;
"baidu")
	echo "百度"
	;;
"guge")
	echo "谷歌"
	;;
esac

