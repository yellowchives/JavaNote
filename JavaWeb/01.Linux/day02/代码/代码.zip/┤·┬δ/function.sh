#!/bin/bash
#shell中的方法


#无参无返回值的方法
method(){
	echo "函数执行了!"
}

#方法的调用
#method



#有参无返回值的方法
method2(){
	echo "接收到的第一个参数$1"
	echo "接收到的第二个参数$2"
}

#方法的调用
#method2 1 2

#有参有返回值方法的定义
method3(){
	echo "接收到的第一个参数$1"
	echo "接收到的第二个参数$2"
	return $(($1 + $2))
}


#方法的调用
method3 10 20
echo $?














