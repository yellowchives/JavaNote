#!/bin/bash
#数组的小练习
#定义一个数组
arr=(a b c d e f)
#给数组中的元素赋值
arr[0]=A
#获取数组中的元素
echo ${arr[0]}
echo ${arr[1]}
#获取数组的长度
echo "数组的长度${#arr[*]}"
echo "数组的长度${#arr[@]}"
