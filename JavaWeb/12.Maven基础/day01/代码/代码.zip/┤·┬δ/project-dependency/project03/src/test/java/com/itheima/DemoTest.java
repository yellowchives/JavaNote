package com.itheima;

public class DemoTest {
    public void test(){
        System.out.println(" test source code plugin...");
    }
}
