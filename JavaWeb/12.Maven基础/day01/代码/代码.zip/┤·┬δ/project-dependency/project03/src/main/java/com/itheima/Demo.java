package com.itheima;

public class Demo {
    public void run(){
        System.out.println(" source code plugin...");
    }
}
