package com.itheima;

public class Demo{
	public String say(String name){
		System.out.println("hello "+ name);
		return "hello "+name;
	}
}