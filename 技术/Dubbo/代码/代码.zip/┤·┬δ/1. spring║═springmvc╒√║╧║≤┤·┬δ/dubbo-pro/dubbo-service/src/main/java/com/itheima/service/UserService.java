package com.itheima.service;

public interface UserService {


    public String sayHello();
}
